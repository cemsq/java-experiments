#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#parse("File Header.java")
public class ${NAME}Builder extends AbstractBuilder<${NAME}> {

    protected ${NAME}Builder(${SERVICE} service) {
        super(new ${NAME}(), service::save);
    }
}
