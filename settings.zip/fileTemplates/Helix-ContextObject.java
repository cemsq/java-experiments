#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.cg.helix.context.annotation.ContextObject;
import com.cg.helix.context.annotation.SingletonScope;

#parse("File Header.java")
@ContextObject
@SingletonScope
public class ${NAME} {

    
}
