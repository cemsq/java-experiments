#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.cg.helix.context.annotation.Inject;
import com.cg.helix.integrationtest.annotation.DatabaseTest;
import com.cg.helix.integrationtest.annotation.TestRuntime;
import com.cgm.storm.StormBaseIntegrationTest;
import com.cgm.storm.environment.PrivilegedLicensedTestEnvironment;

/**
 *
 */
@DatabaseTest
@TestRuntime(testEnvironment = PrivilegedLicensedTestEnvironment.class)
public class ${NAME}Test extends StormBaseIntegrationTest {

    @Inject
    private ${NAME} ${name};
    
    
}