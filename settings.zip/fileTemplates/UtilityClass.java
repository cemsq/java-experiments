#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
public class ${NAME} {

    private ${NAME}() {
        throw new UnsupportedOperationException("You tried to instantiate an utility class, you dirty!!");
    }
}
