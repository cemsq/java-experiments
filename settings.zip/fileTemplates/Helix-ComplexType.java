#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.cg.helix.schemadictionary.annotation.ComplexType;

#parse("File Header.java")
@ComplexType
public class ${NAME} {

    public ${NAME}() {
        // empty constructor for complex types
    }
}
