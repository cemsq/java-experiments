#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.cg.helix.mib.server.annotation.Component;
import com.cg.helix.context.annotation.SingletonScope;

#parse("File Header.java")
@Component
@SingletonScope
public class ${NAME}Impl implements ${NAME} {

    
}
